# motorcontrol
Written specifically for these motor controllers
https://github.com/bgkatz/3phase_integrated
but intended to be easy to port.
 
Written/compiled with ST's Cube IDE:
https://www.st.com/en/development-tools/stm32cubeide.html

Most hardware configuration can be done through hw_config.h

I think it's now fully compatible with the old mbed-based firmware, but let me know if you find bugs.
